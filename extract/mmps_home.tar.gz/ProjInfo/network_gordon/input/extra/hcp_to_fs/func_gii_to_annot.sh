#! /bin/bash


work_dir=${1}
standard_mesh_atlases_dir=${2}

pushd ${work_dir}
mkdir ../label

for hemisphere in "L" "R" ; do
	
	if [ ${hemisphere} == "L" ] ; then
		lowercase="l"
	elif [ ${hemisphere} == "R" ] ; then
		lowercase="r"
	fi
	
	fsaverage_label_gii=Parcels_${hemisphere}_fsaverage_${hemisphere}_164k.label.gii
	resampled_label_gii=Parcels_${hemisphere}_fs_${hemisphere}-to-fs_LR_fsaverage.164k_fs_${hemisphere}.label.gii
	spherical_std_surf_gii=${standard_mesh_atlases_dir}/fs_${hemisphere}/fs_${hemisphere}-to-fs_LR_fsaverage.${hemisphere}_LR.spherical_std.164k_fs_${hemisphere}.surf.gii
	
	wb_command -metric-label-import Parcels_${hemisphere}_fsaverage_${hemisphere}_164k.func.gii '' ${fsaverage_label_gii}
	
	wb_command -label-resample ${fsaverage_label_gii} ${standard_mesh_atlases_dir}/fs_${hemisphere}/fsaverage.${hemisphere}.sphere.164k_fs_${hemisphere}.surf.gii ${spherical_std_surf_gii} BARYCENTRIC ${resampled_label_gii}
	
	mris_convert --annot ${resampled_label_gii} ${spherical_std_surf_gii} ../label/${lowercase}h.Gordon.annot
	
done

popd

